import React from 'react';


function Menu() {
  return (
    <div className='menu bg-gray-800 text-white'>
      <div className="logo flex items-center p-4">
   
        <h2 className="text-lg">Student Dashboard</h2>
      </div>

      <div className="menu--list">
        <a href="#" className="item block py-2 px-4 hover:bg-gray-700">
          Applicants Form
        </a>
        <a href="#" className="item block py-2 px-4 hover:bg-gray-700">
          Applicants History
        </a>
        <a href="#" className="item block py-2 px-4 hover:bg-gray-700">
          Contact Us
        </a>
        <a href="#" className="item block py-2 px-4 hover:bg-gray-700">
          Applicants Form
        </a>
      </div>
    </div>
  );
}

export default Menu;

