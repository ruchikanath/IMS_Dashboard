import React from 'react'
import ContentHeader from './ContentHeader'


const Content = () => {
  return (
    <div className="Content">
        <ContentHeader />
    </div>
  )
}

export default Content;