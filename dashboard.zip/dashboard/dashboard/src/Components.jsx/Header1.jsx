import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';

const Navbar = () => {
    return (
        <nav className="bg-blue-500 p-4">
            <div className="container mx-auto flex items-center justify-between">
                <h1 className="text-white text-lg font-semibold">Student Dashboard</h1>
                <FontAwesomeIcon icon={faUser} className="text-white text-xl" />
            </div>
        </nav>
    );
};

export default Navbar;

