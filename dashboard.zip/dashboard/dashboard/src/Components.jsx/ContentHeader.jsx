import React from 'react';

const ContentHeader = () => {
  return (
    <div className="Content--Header  p-4">
      <h1 class="header--title text-2xl text-blue-500 font-semibold font-serif">Dashboard</h1>

      <div className="flex items-center mt-4">
        <div className="Search-box flex-1 mr-4">
          <input
            type="text"
            placeholder="Search for anything..."
            className="w-full rounded-lg px-4 py-2 bg-gray-700 text-white focus:outline-none focus:bg-gray-600"
          />
        </div>

      </div>
    </div>
  );
};

export default ContentHeader;
