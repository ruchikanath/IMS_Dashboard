import React from 'react';
import Header from './Components.jsx/Header1';


import Card from './Components.jsx/Card';

const App = () => {
  return (
    <>
      <Header />
      <Card />
  
    </>
  );
};

export default App;





